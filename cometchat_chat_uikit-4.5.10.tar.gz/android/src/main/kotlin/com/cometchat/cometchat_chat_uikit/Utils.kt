package com.cometchat.cometchat_chat_uikit
class Utils {
    fun getSDKVersion(): String{
        return BuildConfig.SDK_VERSION
    }
}

