#import <Flutter/Flutter.h>

@interface CometchatChatUikitPlugin : NSObject<FlutterPlugin>
@end
